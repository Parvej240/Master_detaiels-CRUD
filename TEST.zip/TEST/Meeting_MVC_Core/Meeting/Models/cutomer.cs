﻿namespace Meeting.Models
{
    public class cutomer
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
